<?php

$cart=array();
        $sessoid="";
    class Buymodel extends CI_Model{
        function __construct() {
            parent::__construct();            
        }
        
        function insertdatamodel(){   
            $pd="";
            if(isset($_POST['product-quantitya'])) { 
                $this->q= $_POST['product-quantitya'];
                $pd="PR01"; 
            }
            if(isset($_POST['product-quantityc'])) { 
                $this->q= $_POST['product-quantityc'];
                $pd="PR02"; 
            }
            if(isset($_POST['product-quantitye'])) { 
                $this->q= $_POST['product-quantitye'];
                $pd="PR03"; 
            }
            if(isset($_POST['product-quantityb'])) { 
                $this->q= $_POST['product-quantityb'];
                $pd="PR04"; 
            }
            if(isset($_POST['product-quantityd'])) { 
                $this->q= $_POST['product-quantityd'];
                $pd="PR05"; 
            }
            if(isset($_POST['product-quantityf'])) { 
                $this->q= $_POST['product-quantityf'];
                $pd="PR06"; 
            }
            
            $query = $this->db->query("SELECT * from products where pid='$pd'");  
            $row = $query->row_array();
            
            $datas = array(
                'pid' => $pd,
                'quantity' => $this->q,
                
                );
            $this->db->insert('buffer_items', $datas);
            
            $this->load->view('buy-from-us', $datas);
            
        }
        function getcartinfomodel(){
            $cart=array();
            $qrystr="SELECT * from buffer_items";
            $rolqry = $this->db->query($qrystr);
            if($rolqry->num_rows()>0){   
                foreach ($rolqry->result_array() as $rowe) {
                   $qrystr2="SELECT * FROM `products`";
                    $query= $this->db->query($qrystr2);                                           
                    if($query->num_rows()>0){   
                        foreach ($query->result_array() as $row){ 
                                if($rowe['PID']==$row['PID']){
                                    $cart[] = $row['P_IMAGE'];
                                    $cart[] = $row['NAME'];
                                    $cart[] = $rowe['QUANTITY'];
                                    $cart[] = $row['PRICE'];                                    
                                }
                        }
                    }
                }            
            } 
            return $cart;       
        }
        function deletecartmodel(){
            $sql="DELETE FROM `buffer_items`";
            $delqry = $this->db->query($sql);
           
        }
        function inserttoordercart($data,$EM){
            //$indsql = "INSERT INTO order_cart (fname,lname,address1,address2,city,lang,pincode,email)
              //                          VALUES ('$FNAME','$LNAME','$ADDRESS','$ADDRESS2','$CITY','$LANG','$ZIP','$EMAIL')";
                                        if ($this->db->insert('order_cart',$data)) {
                                            $orqry=$this->db->query("SELECT * FROM  order_cart where email='$EM'");
                                            if($orqry->num_rows()>0){ 
                                                foreach($orqry->result_array() as $row){
                                                    $_SESSION['oid']=$row['OID'];
                                                }                                                 
                                                 $sessoid=$_SESSION['oid'];  
                                            }   
                                                                                   
                                            $sql = "SELECT pid,quantity FROM buffer_items";
                                            $result = $this->db->query($sql);
                                            
                                            if ($result->num_rows()>0) {
                                            // output data of each row
                                                foreach($result->result_array() as $row){
                                                    $row1 = $row['pid'];
                                                    $row2 = $row['quantity'];
                                                    
                                                    $fdat=array(
                                                        'oid'=>$sessoid,
                                                        'pid'=>$row1,
                                                        'quantity'=>$row2
                                                    );
                                                    $this->db->insert('order_items',$fdat);
                                                }
                                            } 
            }
        }
    }    
?>