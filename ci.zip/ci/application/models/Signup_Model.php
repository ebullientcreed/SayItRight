<?php
    class Signup_model extends CI_Model{
        function __construct() {
            parent::__construct();
            
        }
        function form_insert($sdata,$EM,$PD){
           
           $rolid=$rolqry=$row="";
            //Checking if the email address is already in use
            $query=$this->db->query("SELECT * FROM `user_log` where email='$EM'");
            if($query->num_rows()==0){
                    
                $Ind='Individual';
                $fdata=array(
                    'USER_ROLE'=>$Ind,
                    'EMAIL'=>$EM,
                    'PWD'=>$PD
                );
                $this->db->insert('user_log',$fdata);
                $rolqry=$this->db->query("SELECT * FROM `user_log` where email='$EM'");
                if($rolqry->num_rows()>0){
                    $row=$rolqry->row();
                    $rolid= $row->ROLE_ID;
                    $ndata=array(
                                'FNAME'=>$sdata['FNAME'],
                                'LNAME'=>$sdata['LNAME'],
                                'WORKPLACE'=>$sdata['PLACE'],
                                'SCHOOL'=>$sdata['SCHOOLNAME'],
                               'ROLE_ID'=>$rolid
                    );
                    $this->db->insert('individual_log',$ndata);
                }                                                            
                         
            }
            
        }                                       
        function form_eveinsert($sdata,$EM,$PD){
           
            $rolid=$rolqry=$row="";
             //Checking if the email address is already in use
             $query=$this->db->query("SELECT * FROM `user_log` where email='$EM'");
             if($query->num_rows()==0){
                     
                 $Ind='EventAdmin';
                 $fdata=array(
                     'USER_ROLE'=>$Ind,
                     'EMAIL'=>$EM,
                     'PWD'=>$PD
                 );
                 $this->db->insert('user_log',$fdata);
                 $rolqry=$this->db->query("SELECT * FROM `user_log` where email='$EM'");
                 if($rolqry->num_rows()>0){
                     $row=$rolqry->row();
                     $rolid= $row->ROLE_ID;
                     $ndata=array(
                                 'FNAME'=>$sdata['FNAME'],
                                 'LNAME'=>$sdata['LNAME'],
                                 
                                'ROLE_ID'=>$rolid
                     );
                     $this->db->insert('event_log',$ndata);
                 }                                                            
                          
             }
             
        }    
        function form_confinsert($sdata,$EM,$PD){
           
            $rolid=$rolqry=$row="";
             //Checking if the email address is already in use
             $query=$this->db->query("SELECT * FROM `user_log` where email='$EM'");
             if($query->num_rows()==0){
                     
                 $Ind='ConferenceAdmin';
                 $fdata=array(
                     'USER_ROLE'=>$Ind,
                     'EMAIL'=>$EM,
                     'PWD'=>$PD
                 );
                 $this->db->insert('user_log',$fdata);
                 $rolqry=$this->db->query("SELECT * FROM `user_log` where email='$EM'");
                 if($rolqry->num_rows()>0){
                     $row=$rolqry->row();
                     $rolid= $row->ROLE_ID;
                     $ndata=array(
                        'TYPE_B' => $sdata['TYPE_B'],
                                 'LNAME'=>$sdata['LNAME'],
                                 
                                'ROLE_ID'=>$rolid
                     );
                     $this->db->insert('business_log',$ndata);
                 }                                                            
                          
             }
             
        }  
    }
?>