<?php


    class Login_Model extends CI_Model{
        
        function __construct() {
            parent::__construct();
            
        }
        function form_check($data,$EM,$PD){
            $ch="";
            $RD="";
            $sql="SELECT * FROM user_log where email='$EM' and pwd='$PD'";
            $query=$this->db->query($sql);
            $row = $query->row();
            if (isset($row)){
                $RD=$row->ROLE_ID;
                $ch=$row->USER_ROLE;
            }
            else{
                $ch="no";
            }
            $arr=array(
                'RD' => $RD,
                'ROLE' => $ch
                
                );
            return $arr;       
        }
        function ind_get($role_id){
            $content=array();
            $current_date = date('Y-m-d');
            $yettoperform=0;
            $performed=0;
            
            $rol=$role_id;
            $cquery=$this->db->query("SELECT * FROM `conf_log` where role_id='$rol'");
            $equery=$this->db->query("SELECT * FROM `events_table` where role_id='$rol'");
            $total=$cquery->num_rows()+$equery->num_rows();
            $cq=$cquery->num_rows();
            $eq=$equery->num_rows();
            $title=$type=$desc=array();
            $i=0;
            if(($cquery->num_rows())>0){
                foreach ($cquery->result_array() as $row){ 
                    $CID=$row['CF_ID'];
                    $rolqry=$this->db->query("SELECT * FROM `conf_list` where cf_id='$CID'");
                    if($rolqry->num_rows()>0){
                        foreach ($rolqry->result_array() as $rowe) {
                            $title[$i]="Conference";
                            $type[$i]=$rowe['TYPE'];
                            $desc[$i]=$rowe['DESCRIPTION'];
                            if($rowe['DATE']>$current_date ){
                                $yettoperform++;
                            }
                            else{
                                $performed++;
                            }
                            $i++;
                        }                                           
                    }                                        
                }
            } 
            if(($equery->num_rows())>0){
           
                foreach ($equery->result_array() as $row){ 
                    $EID=$row['E_ID'];
                    $roleqry=$this->db->query("SELECT * FROM `event_list` where e_id='$EID'");
                    if($roleqry->num_rows()>0){
                        foreach ($roleqry->result_array() as $rowe) {
                            $title[$i]="Event";
                            $type[$i]=$rowe['TYPE'];
                            $desc[$i]=$rowe['DESCRIPTION'];
                            if($rowe['DATE']>$current_date ){
                                $yettoperform++;
                            }
                            else{
                                $performed++;
                            }
                            $i++;
                        }                                           
                    }
                }
            }    
            $content = array(
                'yettoperform' => $yettoperform,
                'performed' =>  $performed,
                'total'=>$total,
                'title'=>$title,
                'type'=>$type,
                'desc'=>$desc,
                'ccount'=>$cq,
                'ecount'=>$eq                    
                );  
            return $content;                         
        
        }
        function conf_get($role_id){
            $cfcontent="";
            $addconfno=0;
            $confno=0;
            $ytype=$ydesc=$ydate=$ysede=$yconfirm=array();
            $acfid=$atype=$adesc=$adate=$asede=$aconfirm=array();
            $addConf=true;
            $x=0;
            $y=0;
            $query=$this->db->query("SELECT * FROM `conf_list`;");
            if($query->num_rows()>0){
                
                foreach ($query->result_array() as $rowe){ 
                    $CID=$rowe['CF_ID'];
                    $rlquery=$this->db->query("SELECT * FROM `conf_log` where role_id='$role_id' and cf_id='$CID'");
                    $row = $rlquery->row();
                    if(isset($row)){
                        $addConf=false;
                        
                        $ytype[$x]=$rowe['TYPE'];
                        $ydesc[$x]=$rowe['DESCRIPTION'];
                        $ydate[$x]=$rowe['DATE'];
                        $ysede[$x]=$rowe['SEDE'];
                        $yconfirm[$x]=$rowe['CONFIRMATION'];
                        $x++;
                    }  
                    else{
                        $addconfno++;
                        $acfid[$y]=$rowe['CF_ID'];
                        $atype[$y]=$rowe['TYPE'];
                        $adesc[$y]=$rowe['DESCRIPTION'];
                        $adate[$y]=$rowe['DATE'];
                        $asede[$y]=$rowe['SEDE'];
                        $aconfirm[$y]=$rowe['CONFIRMATION'];
                        $y++;
                    }                              
                    $confno++;
                }
            }
            $cfcontent = array(
                'type' => $ytype,
                'desc' =>  $ydesc,
                'date'=>$ydate,
                'sede'=>$ysede,
                'confirm'=>$yconfirm,
                'addcfid'=>$acfid,
                'addtype'=>$atype,
                'adddesc'=>$adesc,
                'adddate'=>$adate,
                'addsede'=>$asede,
                'addconfirm'=>$aconfirm ,    
                'addconfno'=> $addconfno,
                'totalconf'=> $confno               
            ); 
            return $cfcontent;
        }
        function add_conf($role_id){
            
            $fdat=array(
                'role_id'=>$role_id,
                'cf_id'=>$_POST['addfield'],
                'upd_cnf'=>0
            );
            $this->db->insert('conf_log', $fdat);
        }
        function eve_get($role_id){
            $cfcontent="";
            $addconfno=0;
            $confno=0;
            $ytype=$ydesc=$ydate=$ysede=$yconfirm=array();
            $acfid=$atype=$adesc=$adate=$asede=$aconfirm=array();
            $addConf=true;
            $x=0;
            $y=0;
            $query=$this->db->query("SELECT * FROM `event_list`;");
            if($query->num_rows()>0){
                
                foreach ($query->result_array() as $rowe){ 
                    $CID=$rowe['E_ID'];
                    $rlquery=$this->db->query("SELECT * FROM `events_table` where role_id='$role_id' and e_id='$CID'");
                    $row = $rlquery->row();
                    if(isset($row)){
                        $addConf=false;
                        
                        $ytype[$x]=$rowe['TYPE'];
                        $ydesc[$x]=$rowe['DESCRIPTION'];
                        $ydate[$x]=$rowe['DATE'];
                        $ysede[$x]=$rowe['SEDE'];
                        $yconfirm[$x]=$rowe['CONFIRMATION'];
                        $x++;
                    }  
                    else{
                        $addconfno++;
                        $acfid[$y]=$rowe['E_ID'];
                        $atype[$y]=$rowe['TYPE'];
                        $adesc[$y]=$rowe['DESCRIPTION'];
                        $adate[$y]=$rowe['DATE'];
                        $asede[$y]=$rowe['SEDE'];
                        $aconfirm[$y]=$rowe['CONFIRMATION'];
                        $y++;
                    }                              
                    $confno++;
                }
            }
            $cfcontent = array(
                'type' => $ytype,
                'desc' =>  $ydesc,
                'date'=>$ydate,
                'sede'=>$ysede,
                'confirm'=>$yconfirm,
                'addcfid'=>$acfid,
                'addtype'=>$atype,
                'adddesc'=>$adesc,
                'adddate'=>$adate,
                'addsede'=>$asede,
                'addconfirm'=>$aconfirm ,    
                'addconfno'=> $addconfno,
                'totalconf'=> $confno               
            ); 
            return $cfcontent;
        }
        function add_eve($role_id){
            
            $fdat=array(
                'role_id'=>$role_id,
                'e_id'=>$_POST['addfield'],
                'upd_evt'=>0
            );
            $this->db->insert('events_table', $fdat);
        }
        function myconf_get($role_id){

            $cfcontent="";
            $addconfno=0;
            $confno=0;
            $ytype=$ydesc=$ydate=$ysede=$yconfirm=array();
            $x=0;
            $y=0;
            $query=$this->db->query("SELECT * FROM `conf_log` where role_id='$role_id'");
            if($query->num_rows()>0){
                foreach($query->result_array() as $rowe){ 
                    $cid=$rowe['CF_ID'];
                    $rolqry=$this->db->query("SELECT * FROM `conf_list` where cf_id='$cid'");
                    $row = $rolqry->row();
                    if(isset($row)){
                        $addConf=false;
                        $ytype[$x]=$row->TYPE;
                        $ydesc[$x]=$row->DESCRIPTION;
                        $ydate[$x]=$row->DATE;
                        $ysede[$x]=$row->SEDE;
                        $yconfirm[$x]=$row->CONFIRMATION;
                        $x++;
                    }
                    $confno++;     
                }
            }
            $cfcontent = array(
                'type' => $ytype,
                'desc' =>  $ydesc,
                'date'=>$ydate,
                'sede'=>$ysede,
                'confirm'=>$yconfirm,
                'totalconf'=> $confno               
            ); 
            return $cfcontent;
        }
        function delmyconf($role_id){
            $options=array();
            $cfcontent=array();
            $x=0;
            $queryitem =$this->db->query( "SELECT DISTINCT cf_id FROM conf_log where role_id='$role_id'");
           // if($queryitem->num_rows()>0) {
                foreach($queryitem->result_array() as $row){ 
                    $options[$x]=$row['cf_id'];
                    $x++;
                }
            //}
            $cfcontent = array(
                'options' => $options,
                'size' =>  $x
            );
            return $cfcontent;
        }
        function deltheconf($itm){
            $delqry=$this->db->query("DELETE FROM conf_log WHERE cf_id='$itm'");
        }
        function myeve_get($role_id){
            
            $cfcontent="";
            $addconfno=0;
            $confno=0;
            $ytype=$ydesc=$ydate=$ysede=$yconfirm=array();
            $x=0;
            $y=0;
            $query=$this->db->query("SELECT * FROM `events_table` where role_id='$role_id'");
            if($query->num_rows()>0){
                foreach($query->result_array() as $rowe){ 
                    $cid=$rowe['E_ID'];
                    $rolqry=$this->db->query("SELECT * FROM `event_list` where e_id='$cid'");
                    $row = $rolqry->row();
                    if(isset($row)){
                        $addConf=false;
                        $ytype[$x]=$row->TYPE;
                        $ydesc[$x]=$row->DESCRIPTION;
                        $ydate[$x]=$row->DATE;
                        $ysede[$x]=$row->SEDE;
                        $yconfirm[$x]=$row->CONFIRMATION;
                        $x++;
                    }
                    $confno++;     
                }
            }
            $cfcontent = array(
                'type' => $ytype,
                'desc' =>  $ydesc,
                'date'=>$ydate,
                'sede'=>$ysede,
                'confirm'=>$yconfirm,
                'totalconf'=> $confno               
            ); 
            return $cfcontent;
        }
        function delmyeve($role_id){
            $options=array();
            $cfcontent=array();
            $x=0;
            $queryitem =$this->db->query( "SELECT DISTINCT e_id FROM events_table where role_id='$role_id'");
           // if($queryitem->num_rows()>0) {
                foreach($queryitem->result_array() as $row){ 
                    $options[$x]=$row['e_id'];
                    $x++;
                }
            //}
            $cfcontent = array(
                'options' => $options,
                'size' =>  $x
            );
            return $cfcontent;
        }
        function deltheeve($itm){
            $delqry=$this->db->query("DELETE FROM events_table WHERE e_id='$itm'");
        }
        function settings($rol,$data,$EM,$PD){
            $query=$this->db->query("SELECT * FROM `user_log` where email='$EM' and pwd='$PD' and role_id='$rol'");
                    if($query->num_rows()>0){
                        //inserting into user_log
                      
                            $changeimage=$_POST['changeimage'];
                            $fname=$data['fname'];
                            $lname=$data['lname'];
                            $workplace=$data['place'];
                            $schoolname=$data['schoolname'];
                            //inserting into individual_log
                            if(isset($_POST['changeimage'])){
                                $changeimage=$_POST["changeimage"];
                                $indsql=$this->db->query("UPDATE individual_log
                                SET fname='$fname',lname='$lname',workplace='$workplace',school='$schoolname',user_image='$changeimage'
                                WHERE role_id='$rol';");
                              return $changeimage;  
                            }
                            else{
                                $indsql=$this->db->query("UPDATE individual_log
                               SET fname='$fname',lname='$lname',workplace='$workplace',school='$schoolname' 
                                WHERE role_id='$rol';");
                                return;
                            }
                            
                             
                        
                
                    }   
        }
        function checkImage($role_id){
            $query= $this->db->query("SELECT user_image FROM `individual_log` where role_id='$role_id'");
            $row = $query->row();
            $res=$row->user_image;
            return $res;
        }
        function settingsPass($rol,$fdata){
            $pwd=$fdata['pwd'];
            $newpwd=$fdata['newpwd'];
            $renewpwd=$fdata['renewpwd'];
            $query=$this->db->query("SELECT * FROM `user_log` where PWD='$pwd' and ROLE_ID='$rol'");
            $row = $query->row();
                    if(isset($row)){
                        //inserting into user_log
                        if($newpwd==$renewpwd){
                            $query=$this->db->query("UPDATE  user_log
                            SET pwd='$newpwd'
                            WHERE role_id='$rol'");                          
                        }
                    } 
        }
        //End Individual
        
        //Event Admin
        function eaget($rol){
            $ytype=$ydesc=$ydate=$ysede=$yconfirm=array();
            $x=0;
            $query=$this->db->query("SELECT * FROM `events_table` where role_id='$rol'");
                                if($query->num_rows()>0){
                                    foreach ($query->result_array() as $row){ 
                                        $eid=$row['E_ID'];
                                        $rolqry= $query=$this->db->query("SELECT * FROM `event_list` where e_id='$eid'");
                                        if($rolqry->num_rows()>0){
                                            foreach ($rolqry->result_array() as $rowe){ 
                                                $ytype[$x]=$rowe['TYPE'];
                                                $ydesc[$x]=$rowe['DESCRIPTION'];
                                                $ydate[$x]=$rowe['DATE'];
                                                $ysede[$x]=$rowe['SEDE'];
                                                $yconfirm[$x]=$rowe['CONFIRMATION'];
                                                $x++;
                                            }
                                            
                                        }
                                       
                                    }
                                }
                                $cfcontent = array(
                                    'type' => $ytype,
                                    'desc' =>  $ydesc,
                                    'date'=>$ydate,
                                    'sede'=>$ysede,
                                    'confirm'=>$yconfirm,
                                    
                                    'totalconf'=> $x               
                                ); 
                                return $cfcontent;

           
        }
      
        function eaaddeveinsert($rol,$fdat){
            $this->db->insert('event_list',$fdat);
           $eid=$this->db->insert_id();
            $gdat=array(
                'role_id'=>$rol,
                'e_id'=>$eid,
                'upd_evt'=>1
            );
            $this->db->insert('events_table',$gdat);                            
        }
        function eadeleve($itm){
            $delqry=$this->db->query("DELETE FROM events_table WHERE e_id='$itm'");
            $deleltqry=$this->db->query("DELETE FROM event_list WHERE e_id='$itm'");
        }
        function eagetevelist($itm){
            $yeid=$ytype=$ydesc=$ydate=$ysede=$yconfirm="";
            $x=0;
            
                                        $rolqry= $query=$this->db->query("SELECT * FROM `event_list` where e_id='$itm'");
                                        if($rolqry->num_rows()>0){
                                            foreach ($rolqry->result_array() as $rowe){ 
                                                $yeid=$rowe['E_ID'];
                                                $ytype=$rowe['TYPE'];
                                                $ydesc=$rowe['DESCRIPTION'];
                                                $ydate=$rowe['DATE'];
                                                $ysede=$rowe['SEDE'];
                                                $yconfirm=$rowe['CONFIRMATION'];
                                                $x++;
                                            }
                                            
                                        }
                                       
                                  
                                $cfcontent = array(
                                    'eid'=>$yeid,
                                    'type' => $ytype,
                                    'desc' =>  $ydesc,
                                    'date'=>$ydate,
                                    'sede'=>$ysede,
                                    'confirm'=>$yconfirm,
                                    
                                    'totalconf'=> $x               
                                ); 
                                return $cfcontent;
        }
        function eachangedate($dt){
            $eid=$this->session->userdata('EVEID');
            $indsql=$this->db->query("UPDATE event_list
                    SET date='" . date('Ymd', strtotime($dt)) . "'
                    WHERE e_id='$eid'");
        }
        function eachangefield($dt,$change){
            $eid=$this->session->userdata('EVEID');
            $indsql=$this->db->query("UPDATE event_list
                    SET $change='$dt'
                    WHERE e_id='$eid'");
        }
        //**End Event */
        //Conference Admin
        function confget($rol){
            $ytype=$ydesc=$ydate=$ysede=$yconfirm=array();
            $x=0;
            $query=$this->db->query("SELECT * FROM `conf_log` where role_id='$rol'");
                                if($query->num_rows()>0){
                                    foreach ($query->result_array() as $row){ 
                                        $eid=$row['CF_ID'];
                                        $rolqry= $query=$this->db->query("SELECT * FROM `conf_list` where cf_id='$eid'");
                                        if($rolqry->num_rows()>0){
                                            foreach ($rolqry->result_array() as $rowe){ 
                                                $ytype[$x]=$rowe['TYPE'];
                                                $ydesc[$x]=$rowe['DESCRIPTION'];
                                                $ydate[$x]=$rowe['DATE'];
                                                $ysede[$x]=$rowe['SEDE'];
                                                $yconfirm[$x]=$rowe['CONFIRMATION'];
                                                $x++;
                                            }
                                            
                                        }
                                       
                                    }
                                }
                                $cfcontent = array(
                                    'type' => $ytype,
                                    'desc' =>  $ydesc,
                                    'date'=>$ydate,
                                    'sede'=>$ysede,
                                    'confirm'=>$yconfirm,
                                    
                                    'totalconf'=> $x               
                                ); 
                                return $cfcontent;

           
        }
      
        function confaddeveinsert($rol,$fdat){
            $this->db->insert('conf_list',$fdat);
           $eid=$this->db->insert_id();
            $gdat=array(
                'role_id'=>$rol,
                'cf_id'=>$eid,
                'upd_cnf'=>1
            );
            $this->db->insert('conf_log',$gdat);                            
        }
        function confdeleve($itm){
            $delqry=$this->db->query("DELETE FROM conf_log WHERE cf_id='$itm'");
            $deleltqry=$this->db->query("DELETE FROM conf_list WHERE cf_id='$itm'");
        }
        function confgetevelist($itm){
            $yeid=$ytype=$ydesc=$ydate=$ysede=$yconfirm="";
            $x=0;
            
                                        $rolqry= $query=$this->db->query("SELECT * FROM `conf_list` where cf_id='$itm'");
                                        if($rolqry->num_rows()>0){
                                            foreach ($rolqry->result_array() as $rowe){ 
                                                $yeid=$rowe['CF_ID'];
                                                $ytype=$rowe['TYPE'];
                                                $ydesc=$rowe['DESCRIPTION'];
                                                $ydate=$rowe['DATE'];
                                                $ysede=$rowe['SEDE'];
                                                $yconfirm=$rowe['CONFIRMATION'];
                                                $x++;
                                            }
                                            
                                        }
                                       
                                  
                                $cfcontent = array(
                                    'eid'=>$yeid,
                                    'type' => $ytype,
                                    'desc' =>  $ydesc,
                                    'date'=>$ydate,
                                    'sede'=>$ysede,
                                    'confirm'=>$yconfirm,
                                    
                                    'totalconf'=> $x               
                                ); 
                                return $cfcontent;
        }
        function confchangedate($dt){
            $eid=$this->session->userdata('EVEID');
            $indsql=$this->db->query("UPDATE conf_list
                    SET date='" . date('Ymd', strtotime($dt)) . "'
                    WHERE cf_id='$eid'");
        }
        function confchangefield($dt,$change){
            $eid=$this->session->userdata('EVEID');
            $indsql=$this->db->query("UPDATE conf_list
                    SET $change='$dt'
                    WHERE cf_id='$eid'");
        }
    }
?>
   