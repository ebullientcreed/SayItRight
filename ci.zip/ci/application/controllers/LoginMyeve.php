<?php
defined('BASEPATH') OR exit('No direct script access allowed');
ob_start();
class LoginMyeve extends CI_Controller {
    
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
    function __construct()
    {
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('Login_Model');
      
        $this->load->library('session');


    }
	public function index()
	{
        $IN = $this->session->userdata('RD');
        $cfcontent=array();
        $cfcontent=$this->Login_Model->myeve_get($IN);
        $data = array(
            'type' => $cfcontent['type'],
            'desc' =>  $cfcontent['desc'],
            'date'=>$cfcontent['date'],
            'sede'=>$cfcontent['sede'],
            'confirm'=>$cfcontent['confirm'],
            
            'totalconf'=>$cfcontent['totalconf']                      
        ); 
		$this->load->view('login-myevents',$data);            
        
    }
    
    public function DelEve(){
        $IN = $this->session->userdata('RD');
        if(isset($_POST['deleve'])){
            $options=$this->Login_Model->delmyeve($IN);
            $data = array(
                'options'=>$options['options'],
                'size'=>$options['size']
            );
            $this->load->view('del_myevent',$options);
        }
        
    }
    public function DelMyConf(){
        if(isset($_POST['deleteeve'])){
            $itm=$_POST['item'];  
            $itm=$this->Login_Model->deltheeve($itm);      
            
            //$this->load->view('de',$itm);
            redirect('/LoginMyeve');
        }
    }
    
}