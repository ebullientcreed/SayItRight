<?php
defined('BASEPATH') OR exit('No direct script access allowed');
ob_start();
class EveAddEve extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
    function __construct()
    {
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('Login_Model');
        $this->load->library('session');

    }
	public function index()
	{
        $IN = $this->session->userdata('RD');
        $this->load->view('add_event'); 
               
        
    }
    public function AddEve(){
        $content=array();
        $IN = $this->session->userdata('RD');
        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('<div class="error">', '</div>');
        $this->form_validation->set_rules('type', 'Type', 'required|callback__validt');
        $this->form_validation->set_rules('place', 'Place', 'required|callback__validt');
        $this->form_validation->set_rules('confirm', 'Confirm', 'required|callback__validt');
        if ($this->form_validation->run() == FALSE) {
           
            redirect('/EveLogin');      
        } 
        else{
            $fdata = array(
                'TYPE' => $this->input->post('type'),
                'DESCRIPTION' => $this->input->post('comment'),
                'SEDE' => $this->input->post('place'),
                'CONFIRMATION' => $this->input->post('confirm'),
                'DATE' => $this->input->post('dates')               
                
            );
            
            $this->Login_Model->eaaddeveinsert($IN,$fdata);
            redirect('/EveLogin');
        }
       
		
    }
    public function _validt($check) {
            if (preg_match("#^[a-zA-Z ]*$#", $check ) ) 
            {

            return TRUE;
            } 
            else 
            {
                $this->form_validation->set_message('_validplace', 'The %s field must only contain Alphabets');
                return FALSE;
            }
    }

       
}