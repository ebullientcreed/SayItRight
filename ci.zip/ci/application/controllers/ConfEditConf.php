<?php
defined('BASEPATH') OR exit('No direct script access allowed');
ob_start();
class ConfEditConf extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
    function __construct()
    {
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('Login_Model');
        $this->load->library('session');

    }
	public function index()
	{
        $IN = $this->session->userdata('RD');
      
            $options=$this->Login_Model->delmyconf($IN);
            $data = array(
                'options'=>$options['options'],
                'size'=>$options['size']
            );
            $this->load->view('edit_conf',$options);
       
           
        
        
    }
    public function EditMyEve(){
        if(isset($_POST['editeve']) && isset($_POST['changefield'])){
            $ED= $this->session->userdata('EVEID');
            $fdat=array();
            if( $_POST['changefield'] == 'type'){
                $change="type";
                $fdat=array(
                    'ED'=>$ED,
                    'change'=>$change
                );
                $t="type";
                $this->session->set_userdata('change',$t);
                $this->load->view('edit_conf_content',$fdat);                                          
            }
            else if( $_POST['changefield'] == 'desc'){
                $change="description";
                $fdat=array(
                    'ED'=>$ED,
                    'change'=>$change
                );
               
                $this->session->set_userdata('change',$change);
                $this->load->view('edit_conf_content',$fdat);                                         
            }
            else if( $_POST['changefield'] == 'sede'){
                $change="sede";
                $fdat=array(
                    'ED'=>$ED,
                    'change'=>$change
                );
               
                $this->session->set_userdata('change',$change);
                $this->load->view('edit_conf_content',$fdat);                                    
            }
            else if( $_POST['changefield'] == 'conf'){
                $change="confirmation";
                $fdat=array(
                    'ED'=>$ED,
                    'change'=>$change
                );
             
                $this->session->set_userdata('change',$change);
                $this->load->view('edit_conf_content',$fdat);                                               
            }  
            else if( $_POST['changefield'] == 'dates'){
                $change="date";
                $fdat=array(
                    'ED'=>$ED,
                    'change'=>$change
                );
               
                $this->session->set_userdata('change',$change);
                $this->load->view('edit_conf_content',$fdat); 
            }     
        }
        else if(isset($_POST['editeve'])){
            $itm=$_POST['item'];  
            $content=$this->Login_Model->confgetevelist($itm);      
            
            $data = array(
                'eid'=>$content['eid'],
                'type' => $content['type'],
                'desc' =>  $content['desc'],
                'date'=>$content['date'],
                'sede'=>$content['sede'],
                'confirm'=>$content['confirm'],
                
                'totalconf'=> $content['totalconf']    
                   
    
            );
            $this->session->set_userdata('EVEID',$data['eid']);
            $cont=$_POST['editeve'];
            $data['cont']=$cont;  
            //$this->load->view('de',$itm);
            $this->load->view('edit_conf',$data);
        }
        
    }
    public function EditMyEveDate(){
        if(isset($_POST['editeve'])){
            $newtpe=$_POST['editdate'];
            $this->Login_Model->confchangedate($newtpe);   
        }
        redirect('/ConfLogin');
    }
    public function EditMyEveType(){
        if(isset($_POST['editeve'])){
            $newtpe=$_POST['editevetype'];
            $change=$this->session->userdata('change');
            $this->Login_Model->confchangefield($newtpe,$change);   
        }
        redirect('/ConfLogin');
    }
    public function _validt($check) {
            if (preg_match("#^[a-zA-Z ]*$#", $check ) ) 
            {

            return TRUE;
            } 
            else 
            {
                $this->form_validation->set_message('_validplace', 'The %s field must only contain Alphabets');
                return FALSE;
            }
    }

       
}