<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ContactCheck extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('Contact_Model');
    }
    function index() {
    
        

		$this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('<div class="error">', '</div>');

        //Validating FirstName Field
        $this->form_validation->set_rules('firstname', 'FirstName', 'required|callback__validfirstname');
        //Validating LastName Field
        $this->form_validation->set_rules('lastname', 'LastName', 'required|callback__validlastname');

       

        //Validating Telephone Field
        $this->form_validation->set_rules('telephone', 'Mobile No.', 'required|callback__validatetelephone');

        

        if ($this->form_validation->run() == FALSE) {
           
            $this->load->view('contact');            
        } 
        else{
        //Setting values for tabel columns
            $data = array(
            'FNAME' => $this->input->post('firstname'),
            'LNAME' => $this->input->post('lastname'),
            'PHONE' => $this->input->post('telephone'),
            'MESSAGE' => $this->input->post('message')
            );
            
            //Transfering data to Model
            $this->Contact_Model->form_insert($data);
            $data['message'] = 'Data Inserted Successfully';
            //Loading View
            $this->load->view('contact', $data);
        }
        
    }
    public function _validatetelephone($telephone) {
        if (preg_match("#^(\(\d{3}\)[\s.-]?|\d{3}[\s.-]?)?\d{3}[\s.-]?\d{4}$#", $telephone ) ) 
        {

          return TRUE;
        } 
        else 
        {
            $this->form_validation->set_message('_validatetelephone', 'The %s field must only contain numbers');
            return FALSE;
        }
      }
      public function _validfirstname($firstname) {
        if (preg_match("#^([a-z]+)|([A-Z]+|[A-Z][a-z]+)$#", $firstname ) ) 
        {

          return TRUE;
        } 
        else 
        {
            $this->form_validation->set_message('_validfirstname', 'The %s field must only contain Alphabets');
            return FALSE;
        }
      }
      public function _validlastname($lastname) {
        if (preg_match("#^([a-z]+)|([A-Z]+|[A-Z][a-z]+)$#", $lastname ) ) 
        {

          return TRUE;
        } 
        else 
        {
            $this->form_validation->set_message('_validlastname', 'The %s field must only contain Alphabets');
            return FALSE;
        }
      }
}

?>
 