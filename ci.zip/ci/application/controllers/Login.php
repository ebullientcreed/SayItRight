<?php
defined('BASEPATH') OR exit('No direct script access allowed');
ob_start();
class Login extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
    function __construct()
    {
        parent::__construct();
     
        $this->load->model('Login_Model');
       
    }
	public function index()
	{
        
		$this->load->view('login');
		
    }
    public function logCheck(){
        $this->load->library('session');
        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('<div class="error">', '</div>');

        $this->form_validation->set_rules('email', 'Email', 'required|callback__validemail');
         //Validating password Field
        $this->form_validation->set_rules('password', 'Password', 'required|callback__validpassword');
        if ($this->form_validation->run() == FALSE) {
           
            $this->load->view('login');            
        } 
        else{
        //Setting values for tabel columns
            $sdata = array(
            'EMAIL' => $this->input->post('email'),
            'PASSWORD' => $this->input->post('password'),
            
            );
            $EM=$this->input->post('email');
            $PD=$this->input->post('password');
            
            //Transfering data to Model
            $user=$this->Login_Model->form_check($sdata,$EM,$PD);
            //$this->load->view('login',$user);
            $data['user']=$user['ROLE'];
            
            if(strcmp($user['ROLE'], 'no') == 0){
                $data['user']="Wrong Credentials";
                $this->load->view('login',$data);
            }
            else if(strcmp($user['ROLE'],'Individual')== 0){
                $this->session->set_userdata('RD',$user['RD']);
                redirect('/LoginInd');
                
            }
            else if(strcmp($user['ROLE'],'EventAdmin')== 0){
                $this->session->set_userdata('RD',$user['RD']);
                redirect('/EveLogin');
            }
            else if(strcmp($user['ROLE'],'ConferenceAdmin')== 0){
                $this->session->set_userdata('RD',$user['RD']);
                redirect('/ConfLogin');
            }
            
        }
    }
    public function _validemail($email) {
        if (preg_match("#^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$#", $email ) ) 
        {

          return TRUE;
        } 
        else 
        {
            $this->form_validation->set_message('_validemail', 'The Email field is invalid');
            return FALSE;
        }
    }
    public function _validpassword($pwd) {
        if (strlen($pwd) <= '4') {
            
            $this->form_validation->set_message('_validpassword', 'Your Password Must Contain At Least 4 Characters!');
            return FALSE;
        }
        elseif(!preg_match("#[0-9]+#",$pwd)) {
          
            $this->form_validation->set_message('_validpassword', 'Your Password Must Contain At Least 1 Number!');
            return FALSE;
        }
        elseif(!preg_match("#[A-Z]+#",$pwd)) {
           
            $this->form_validation->set_message('_validpassword', 'Your Password Must Contain At Least 1 Capital Letter!');
            return FALSE;
        }
        elseif(!preg_match("#[a-z]+#",$pwd)) {
           
            $this->form_validation->set_message('_validpassword', 'Your Password Must Contain At Least 1 Lowercase Letter!');
            return FALSE;
        } 
        else{
            return TRUE;
        }
    }
}