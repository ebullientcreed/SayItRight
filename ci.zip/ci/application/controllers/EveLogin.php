<?php
defined('BASEPATH') OR exit('No direct script access allowed');
ob_start();
class EveLogin extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
    function __construct()
    {
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('Login_Model');
        $this->load->library('session');

    }
	public function index()
	{
        $IN = $this->session->userdata('RD');
        $content=array();
        $content=$this->Login_Model->eaget($IN);
        $ndata = array(
            'type' => $content['type'],
                                    'desc' =>  $content['desc'],
                                    'date'=>$content['date'],
                                    'sede'=>$content['sede'],
                                    'confirm'=>$content['confirm'],
                                    
                                    'totalconf'=> $content['totalconf']     

        );
		$this->load->view('events_home',$ndata);            
        
    }
    public function update(){
        if(isset($_POST['addeve'])){
           redirect('/EveAddEve');
        } 
        if(isset($_POST['deleve'])){
            redirect('/EveDelEve');
         } 
         if(isset($_POST['editeve'])){
            redirect('/EveEditEve');
         } 
        
    }
	

       
}