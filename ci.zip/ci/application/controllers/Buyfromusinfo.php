<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Buyfromusinfo extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('Buymodel');
    }
    function index() {  
        $cart=$this->Buymodel->getcartinfomodel();
        $data = array();
        $data['carts'] = null;
        if($cart){
            $data['carts']=$cart;
        }  
        $data['title'] = "Title";
        $data['heading'] = "Heading";     
        $this->load->view('buy-from-us-info',$data);           
        
        //Loading View        
    }
}
?>    