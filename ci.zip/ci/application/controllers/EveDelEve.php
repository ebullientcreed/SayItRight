<?php
defined('BASEPATH') OR exit('No direct script access allowed');
ob_start();
class EveDelEve extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
    function __construct()
    {
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('Login_Model');
        $this->load->library('session');

    }
	public function index()
	{
        $IN = $this->session->userdata('RD');
       
            $options=$this->Login_Model->delmyeve($IN);
            $data = array(
                'options'=>$options['options'],
                'size'=>$options['size']
            );
            $this->load->view('del_event',$options);
        
        
    }
    public function DelMyEve(){
        if(isset($_POST['deleteeve'])){
            $itm=$_POST['item'];  
            $itm=$this->Login_Model->eadeleve($itm);      
            
            //$this->load->view('de',$itm);
            redirect('/EveLogin');
        }
    }
    public function _validt($check) {
            if (preg_match("#^[a-zA-Z ]*$#", $check ) ) 
            {

            return TRUE;
            } 
            else 
            {
                $this->form_validation->set_message('_validplace', 'The %s field must only contain Alphabets');
                return FALSE;
            }
    }

       
}