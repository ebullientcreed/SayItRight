<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class BuyFromCheck extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->load->model('Buymodel');
    }
    function index() {  
        
        if(isset($_POST["order-cart-form"])) { 
            
            $this->load->view('buy-from-us-success');
           
        }
        else if(isset($_POST["cart-submit"])) { 
            $data = array(
                
                'FNAME' => $this->input->post('name'),
                'LNAME' => $this->input->post('lname'),
                'ADDRESS1' => $this->input->post('address'),
                'ADDRESS2' => $this->input->post('address2'),
                'CITY' => $this->input->post('city'),                
                'LANG' => $this->input->post('lang'),
                'PINCODE' => $this->input->post('pcode'),
                'EMAIL'=>$this->input->post('email')
                );
                $EM=$this->input->post('email');
                $this->load->library('form_validation');
                $this->form_validation->set_error_delimiters('<div class="error">', '</div>');
        
                //Validating FirstName Field
                $this->form_validation->set_rules('name', 'FirstName', 'required|callback__validfirstname');
                //Validating LastName Field
                $this->form_validation->set_rules('lname', 'LastName', 'required|callback__validlastname');
                
                 $this->form_validation->set_rules('city', 'City', 'required|callback__validcity');
                 //$this->form_validation->set_rules('zip', 'Postal Code', 'required|callback__validpostalcode');
        
                 
        
                //Transfering data to Model
                //$this->Contact_Model->insertcartinfomodel($data);
                
                if ($this->form_validation->run() == FALSE)
                {
                    $this->load->view('buy-from-us-info');
                }
                else{
                    $this->Buymodel->inserttoordercart($data,$EM);
                    $data['message'] = 'Data Inserted Successfully';
                    $this->load->view('buy-from-us-success', $data);
                }
                //Loading View
                
           
           
        } 
        else if(isset($_POST["clear-cart-submit"])){
            $this->Buymodel->deletecartmodel();
            $this->load->view('buy-from-us');
        }
        else if(isset($_POST["buy-from-us-cart-submit"])){
            $data=array();
            $query=$this->Buymodel->getcartinfomodel();
            $data['carts']=null;
            if($query){
                $data['carts']=$query;
            }
            $this->load->view('buy-from-us-info', $data);
        }
        else{
           
            $this->Buymodel->insertdatamodel();
        }      
        
        //Loading View
        
    }
    public function _validcity($city) {
        if (preg_match("#^[a-zA-Z ]*$#",$city) ) 
        {

          return TRUE;
        } 
        else 
        {
            $this->form_validation->set_message('_validcity', 'Invalid city');
            return FALSE;
        }
      }
      public function _validpostalcode($zip) {
        if (preg_match("#\d{5}+#",$zip)) 
        {

          return TRUE;
        } 
        else 
        {
            $this->form_validation->set_message('_validpostalcode', 'Invalid US Postal code');
            return FALSE;
        }
      }
      public function _validfirstname($firstname) {
        if (preg_match("#^([a-z]+)|([A-Z]+|[A-Z][a-z]+)$#", $firstname ) ) 
        {

          return TRUE;
        } 
        else 
        {
            $this->form_validation->set_message('_validfirstname', 'The %s field must only contain Alphabets');
            return FALSE;
        }
      }
      public function _validlastname($lastname) {
        if (preg_match("#^([a-z]+)|([A-Z]+|[A-Z][a-z]+)$#", $lastname ) ) 
        {

          return TRUE;
        } 
        else 
        {
            $this->form_validation->set_message('_validlastname', 'The %s field must only contain Alphabets');
            return FALSE;
        }
      }
}
?>    