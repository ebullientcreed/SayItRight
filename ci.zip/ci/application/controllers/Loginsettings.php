<?php
defined('BASEPATH') OR exit('No direct script access allowed');
ob_start();
class Loginsettings extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
    function __construct()
    {
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('Login_Model');
     
        $this->load->library('session');

    }
	public function index()
	{   
        $IN = $this->session->userdata('RD');
        $ig=$this->Login_Model->checkImage($IN);
        $data['change']=$ig;
        $this->load->view('settings',$data);
    }
    public function Edit(){
        $IN = $this->session->userdata('RD');
    
        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('<div class="error">', '</div>');

        //Validating FirstName Field
        $this->form_validation->set_rules('name', 'FirstName', 'required|callback__validfirstname');
        //Validating LastName Field
        $this->form_validation->set_rules('lname', 'LastName', 'required|callback__validlastname');
        //Validating place Field
        $this->form_validation->set_rules('place', 'Place', 'required|callback__validplace');
        //Validating schoolname Field
        $this->form_validation->set_rules('schoolname', 'Schoolname', 'required|callback__validschoolname');
        //Validating email Field
        $this->form_validation->set_rules('email', 'Email', 'required|callback__validemail');
         //Validating password Field
        $this->form_validation->set_rules('password', 'Password', 'required|callback__validpassword');

        

        if ($this->form_validation->run() == FALSE) {
           
            $this->load->view('settings');       
        } 
        else{
        //Setting values for tabel columns
            $fdata = array(
            'fname' => $this->input->post('name'),
            'lname' => $this->input->post('lname'),
            'place' => $this->input->post('place'),
            'schoolname' => $this->input->post('schoolname'),
            'EMAIL' => $this->input->post('email'),
            'PASSWORD' => $this->input->post('password')
            );
            $EM=$this->input->post('email');
            $PD=$this->input->post('password');
            $change=$this->Login_Model->settings($IN,$fdata,$EM,$PD);
        
            //Transfering data to Model
          
            $data['message'] = 'Data Inserted Successfully';
            $data['change']=$change;
            //Loading View
            $this->load->view('settings',$data);   
        }
        
    }
    
    public function _validfirstname($firstname) {
        if (preg_match("#^[a-zA-Z ]*$#", $firstname ) ) 
        {

          return TRUE;
        } 
        else 
        {
            $this->form_validation->set_message('_validfirstname', 'The %s field must only contain Alphabets');
            return FALSE;
        }
    }
    public function _validlastname($lastname) {
        if (preg_match("#^[a-zA-Z ]*$#", $lastname ) ) 
        {

          return TRUE;
        } 
        else 
        {
            $this->form_validation->set_message('_validlastname', 'The %s field must only contain Alphabets');
            return FALSE;
        }
    }
    public function _validplace($place) {
        if (preg_match("#^[a-zA-Z ]*$#", $place ) ) 
        {

          return TRUE;
        } 
        else 
        {
            $this->form_validation->set_message('_validplace', 'The %s field must only contain Alphabets');
            return FALSE;
        }
    }
    public function _validschoolname($schoolname){
        if (preg_match("#^[a-zA-Z ]*#", $schoolname ) ) 
        {

          return TRUE;
        } 
        else 
        {
            $this->form_validation->set_message('_validschoolname', 'The %s field must only contain Alphabets');
            return FALSE;
        }
    }
    public function _validemail($email) {
        if (preg_match("#^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$#", $email ) ) 
        {

          return TRUE;
        } 
        else 
        {
            $this->form_validation->set_message('_validemail', 'The Email field is invalid');
            return FALSE;
        }
    }
    public function _validpassword($pwd) {
        if (strlen($pwd) <= '4') {
            
            $this->form_validation->set_message('_validpassword', 'Your Password Must Contain At Least 4 Characters!');
            return FALSE;
        }
        elseif(!preg_match("#[0-9]+#",$pwd)) {
          
            $this->form_validation->set_message('_validpassword', 'Your Password Must Contain At Least 1 Number!');
            return FALSE;
        }
        elseif(!preg_match("#[A-Z]+#",$pwd)) {
           
            $this->form_validation->set_message('_validpassword', 'Your Password Must Contain At Least 1 Capital Letter!');
            return FALSE;
        }
        elseif(!preg_match("#[a-z]+#",$pwd)) {
           
            $this->form_validation->set_message('_validpassword', 'Your Password Must Contain At Least 1 Lowercase Letter!');
            return FALSE;
        } 
        else{
            return TRUE;
        }
    
		
    }
    public function EditPass(){
        $this->load->view('settings_pass');
        
    }
    public function EditPassCheck(){
        $IN = $this->session->userdata('RD');
    
        $this->load->library('form_validation');
        $this->form_validation->set_error_delimiters('<div class="error">', '</div>');
        $this->form_validation->set_rules('password', 'Password', 'required|callback__validpassword');
        $this->form_validation->set_rules('newpass', 'NewPassword', 'required|callback__validpassword');
        $this->form_validation->set_rules('renewpass', 'ReNewPassword', 'required|callback__validpassword');
        if ($this->form_validation->run() == FALSE) {
           
            redirect('/Loginsettings');      
        } 
        else{
            $fdata = array(
                'pwd' => $this->input->post('password'),
                'newpwd' => $this->input->post('newpass'),
                'renewpwd' => $this->input->post('renewpass')
            );
            
            $this->Login_Model->settingsPass($IN,$fdata);
            redirect('/Loginsettings');
        }
    }
}